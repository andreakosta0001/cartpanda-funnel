# Cartpanda Funnel Builder (Frontend Test)

**Overview**
Visual-only upsell funnel builder with a draggable palette, canvas with pan, node connections, validation hints, and localStorage persistence. Built with React + TypeScript and an HTML Canvas layer for grid + arrows.

**Submission**
Demo URL: `TBD`
GitHub repo: `TBD`

**Features**
- Drag node types from the palette into the canvas
- Pan the canvas for an infinite-ish workspace
- Connect nodes via handles (arrows drawn on canvas)
- Auto-incrementing Upsell/Downsell labels
- LocalStorage persistence with JSON import/export
- Validation panel for funnel rules and orphans

**Local Setup**
1. `npm install`
2. `npm start`
3. Open the URL printed by Parcel (default `http://localhost:1234`)

**Architecture Decisions**
- Canvas is used for the grid + edges while nodes remain HTML for accessibility and easier hit targets.
- A single state source for nodes/edges keeps interactions predictable; utility helpers enforce rules and validation.
- Canvas rendering is derived from state to avoid desync between visuals and data.
- Parcel is used for bundling to keep the stack React-only without Vite.

**Tradeoffs / Improvements Next**
- No zoom or minimap yet to keep the MVP tight.
- Edge deletion is not implemented; a simple edge selection model would be added next.
- Multi-select and keyboard shortcuts (delete/duplicate) would improve power-user flow.

**Accessibility Notes**
- Interactive controls are real buttons with focus-visible styles.
- Status updates are announced in the validation panel using `aria-live`.
- Nodes remain DOM elements to support screen readers (rather than pure canvas).

**Dashboard Architecture Answer**
- See `docs/dashboard-architecture.md`
