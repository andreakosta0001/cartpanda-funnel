# Modern Dashboard Architecture (Cartpanda)

**Goal**
Build a funnels + checkout admin that stays fast as it grows, supports parallel workstreams, and avoids rewrites while meeting WCAG accessibility standards.

**1. Architecture**
I would structure the app around feature modules with clearly owned routes, queries, and UI. Each feature module gets a folder such as `features/funnels`, `features/orders`, `features/customers`, `features/settings`. These modules contain:
- Route entry (page component + route loader)
- Feature-specific components and hooks
- API/query definitions and type schemas

Shared UI and utilities live in `ui/` and `lib/` (design system primitives, layout shell, routing helpers, formatting utilities). I would use React Router for route boundaries and data loaders, and keep routing config in a single `routes.tsx` so navigation is centralized and discoverable.

To avoid spaghetti:
- Feature modules own their state and API calls, not shared "global" folders.
- Cross-cutting UI patterns (tables, filters, empty states) are in `ui/` and imported by features.
- No direct imports between features. Shared code goes through `ui/` or `lib/`.

**2. Design System**
I would build a lightweight internal design system on top of a headless accessibility library (Radix UI or Headless UI). This gives consistent behavior without boxing us into a rigid visual style.

Enforcement strategy:
- Tokens via CSS variables (spacing, color, type scale, radii, shadows).
- Theming in one place to support branding and high-contrast variants.
- Typography scale and semantic components (e.g., `Text`, `Heading`) to reduce ad hoc styles.
- Storybook for visual docs and usage guidance.
- Linting rules to block raw color values outside the theme tokens.

**3. Data Fetching + State**
I would use TanStack Query for server state and caching, and keep client-only state in small stores (Zustand) or local component state.

Guidelines:
- Queries live in each feature folder, not a global API bucket.
- Zod schemas validate and narrow API responses at the boundary.
- Loading/error/empty are handled by shared UI patterns so every page feels consistent.
- Table filters/sorts/pagination are stored in URL search params, making views shareable and back/forward-friendly.
- Server state is the source of truth; avoid duplicating server data in a client store.

**4. Performance**
The dashboard should feel snappy even with large datasets.
- Route-level code splitting using React lazy + dynamic imports.
- Virtualized tables for large datasets (React Window or TanStack Virtual).
- Memoized row renderers and stable column definitions to reduce re-renders.
- Prefetch critical routes on hover or after idle.
- Instrument performance with Web Vitals and custom timings around slow query-to-render cycles.

I would track performance regression using real-user monitoring (Sentry or Datadog) and a lightweight performance budget in CI.

**5. DX & Scaling**
To keep multiple engineers aligned:
- A project template for new features (route, query, schema, tests, story).
- ESLint + Prettier + TypeScript strict mode.
- PR templates that require screenshots, performance impact, and accessibility notes.
- A decision log for architectural changes.
- Shared UI guidelines and quickstart recipes in Storybook.

This reduces one-off UI and makes best practices a default path.

**6. Testing Strategy**
Minimum test set:
- Unit tests for pure utilities, formatting, and schema validation.
- Integration tests for feature flows (filters, pagination, bulk actions).
- E2E tests for critical paths like checkout order creation, refund flow, and permission gating.

I would require at least one integration or E2E test per major feature and aim to keep unit tests fast to encourage coverage.

**7. Release & Quality**
Ship fast but safe:
- Feature flags for risky workflows and staged rollouts.
- Canary release to internal users, then gradual percentage rollout.
- Error monitoring and session replay for debugging.
- CI checks for type safety, linting, and core E2E flows.

Avoiding rewrites:
- Build primitives early and adopt them incrementally.
- Always migrate within the existing system rather than splitting into a new stack.
- Pay down debt within feature work, not in separate rewrite efforts.

**Tradeoffs**
At MVP, I would skip complex offline support and deep customization. I would invest early in routing, query boundaries, and UI primitives because they enable rapid expansion without rework.
